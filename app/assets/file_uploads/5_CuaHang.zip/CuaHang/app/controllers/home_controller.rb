class HomeController < ApplicationController

	layout 'layout'
	skip_before_filter :verify_authenticity_token

	def index

	end

	def signin_process
		user = User.new
		user.save_with_params params

		render 'home/signin_process'
	end
end
