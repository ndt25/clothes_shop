class User < ActiveRecord::Base

	def save_with_params _params
		self.account = _params[:account]
		self.username = _params[:username]
		self.password = _params[:password]
		self.email = _params[:email]

		self.save
	end

end
