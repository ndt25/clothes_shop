$(function () {
	var $form = $('#form_dang_ky');

	$form.on('submit', function (event) {
		var
			$tenDangNhap = $('#ten_dang_nhap'),
			$hoTen = $('#ho_ten'),
			$matKhau = $('#mat_khau'),
			$lapLaiMatKhau = $('#lap_lai_mat_khau'),
			$email = $('#email');

		// Ràng buộc giá trị không được bỏ trống
		// if ($tenDangNhap.val() == '') Ơ
		// 	alert('Tên đăng nhập không được bỏ trống');
		// 	event.preventDefault();
		// 	return;
		// Ư
		if ($hoTen.val() == '') {
			alert('Họ tên không được bỏ trống');
			event.preventDefault();
			return;
		}
		if ($matKhau.val() == '') {
			alert('Mật khẩu không được bỏ trống');
			event.preventDefault();
			return;
		}
		if ($lapLaiMatKhau.val() == '') {
			alert('Lặp lại mật khẩu không được bỏ trống');
			event.preventDefault();
			return;
		}
		if ($email.val() == '') {
			alert('Email không được bỏ trống');
			event.preventDefault();
			return;
		}

		// Ràng buộc mật khẩu trùng khớp
		if ($matKhau.val() != $lapLaiMatKhau.val()) {
			alert('Mật khẩu không trùng khớp');
			event.preventDefault();
			return;
		}

		// Ràng buộc email hợp lệ
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if (!filter.test($email.val())) {
			alert('Email không hợp lệ');
			event.preventDefault();
			return;
		}
	});
});